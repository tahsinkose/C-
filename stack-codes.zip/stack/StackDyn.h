#include <string>
#include <cstdlib>

using namespace std;

template <class Object>
class StackNode
{
    public:
        StackNode(const Object& e = Object(), StackNode* n = NULL)
            : element(e), next(n) {}

        Object element;
        StackNode* next; 
};

template <class Object>
class StackDyn
{
    public:
    StackDyn()
    {
   	top = new StackNode<Object>;
    	count=0;
    }

   ~StackDyn()
   {	
        while (!isEmpty())
		pop();		
	delete top;
   }

    void push(Object data)
    {
        StackNode<Object>* newTop = new StackNode<Object>;
        newTop->element = data;
        newTop->next = top->next;
        top->next = newTop;
        count++;
    }

    Object getTop() throw(string) {
         if (count == 0)
                  throw string("Exception:Stack is empty");
          return top->next->element;
    }


    void pop() throw(string)
    {
    	if(count == 0)
		throw string("Exception:Stack is empty");
    	else
    	{
        	StackNode<Object>* old = top->next;
        	top->next = old->next;
        	count--;
        	delete old;
    	}
    }

    bool isEmpty() {
            return (count == 0);
      }



private:
    StackNode<Object> *top;
    int count; 

};

