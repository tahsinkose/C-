#include <iostream>
#include "Stack.h"
#include <cstdlib>
#include <cctype>

using namespace std;

bool isOperator(char c)
{
	bool flag;
	if ((c=='*')||(c=='/')||(c=='+')||(c=='-'))
		flag=true;
	else 
		flag=false;

	return flag;
}
	

int main()
{

	Stack<int> myStack(100);

	char c;
	int c1,c2;

	cout<<"Start entering the postfix expression: ";

	cin >> c;

	try {
		while (c != '.'){ 
			if (!isOperator(c)) { myStack.push(((int)c)-48);}
			else { 
				c1=myStack.getTop();
				cout<<c1<<endl;
				myStack.pop();
				c2=myStack.getTop();
				cout<<c2<<endl;
				myStack.pop();
				if (c=='*') myStack.push(c2 * c1);
				else if (c=='/') myStack.push(c2 / c1);
				else if (c=='+') myStack.push(c2 + c1);
				else if (c=='-') myStack.push(c2 - c1);
			}
		cin >> c;}
	}
	catch(string s){cout<<s<<endl;}
	
	cout <<"The result is "<<myStack.getTop()<<endl;

	return 0;
}

