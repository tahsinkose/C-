#include <iostream>
#include "Stack.h"
#include <cstdlib>

using namespace std;

int main()
{

	Stack<char> myStack(100);
	char c;
	bool isPalindrome=true;

	cout<<"Start entering text: ";

	cin >> c;

	try {
		while (c != '$'){ 
			myStack.push(c);
			cin >> c;
			}
	}
	catch(string s){cout<< s <<endl; }

	cin >> c;
	while (isPalindrome && (c!='.')) {
		if (myStack.isEmpty()) isPalindrome=false;
		else if (c!=myStack.getTop()) isPalindrome=false;
		else myStack.pop();
		cin >> c;
	}
  
	if (isPalindrome) cout<<"Yesss! The string is palindrome"<<endl;
	else cout<< "Nooo! It is not palindrome" <<endl;


	return 0;
}
