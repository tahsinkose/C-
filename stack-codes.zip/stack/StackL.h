#include <string>
#include <cstdlib>
#include <iostream>

using namespace std;


template <class Object>
class ListNode
{
    public:
        ListNode(const Object& e = Object(), ListNode* n = NULL)
            : element(e), next(n) {}

        Object element;
        ListNode* next;
};

template <class Object>
class List
{
    public:
        List() 
        { 
            head = new ListNode<Object>(); 
        }

        List(const List& rhs)
        {
            head = new ListNode<Object>();
            *this = rhs; // reuse assignment operator
        }

        ~List()
        {
            makeEmpty();
            delete head;
        }

        /*List& operator=(const List& rhs)
        {
            if (this != &rhs) // avoid self-assignment
            {
                makeEmpty();

                ListNode<Object>* p = zeroth();
                ListNode<Object>* r = rhs.first();

                for (; r != NULL; p = p->next, r = r->next)
                {
                    insert(r->element, p);
                }
            }

            return *this;
        }

*/
        bool isEmpty() const
        {
            return head->next == NULL;
        }

        bool makeEmpty()
        {
            while (!isEmpty())
            {
                remove(first()->element);
            }
        }

        ListNode<Object>* zeroth() const
        {
            return head;
        }

        ListNode<Object>* first() const
        {
            return head->next;
        }

        void insert(const Object& x, ListNode<Object>* p)
        {
            // insert a new node next to node pointed by p
            if (p)
            {
                p->next = new ListNode<Object>(x, p->next);
            }
        }

        ListNode<Object>* find(const Object& x) const
        {
            // return the first node that contains element x

            ListNode<Object>* p = head->next;

            for (; p != NULL; p = p->next)
            {
                if (p->element == x)
                {
                    break;
                }
            }

            return p;
        }

        ListNode<Object>* findPrevious(const Object& x) const
        {
            // return the node that points the node containing element x
            // returns NULL if x is not in the list

            ListNode<Object>* p = head;

            for (; p->next != NULL; p = p->next)
            {
                if (p->next->element == x)
                {
                    break;
                }
            }

            return p->next != NULL ? p : NULL;
        }

        void remove(const Object& x)
        {
            // remove the first node containing element x

            ListNode<Object>* p = findPrevious(x);

            if (p != NULL)
            {
                ListNode<Object>* tmp = p->next;
                p->next = tmp->next;
                delete tmp;
            }
        }

	void print()
	{
		ListNode<Object>* tmp=first();
		if (tmp == NULL)
			cout << "Empty list" << endl;
		else
			printrec(tmp);
	}

	void printRev()
	{
		ListNode<Object>* tmp=first();
		if (tmp == NULL)
			cout << "Empty list" << endl;
		else
			printRevrec(tmp);
	}
		

	bool isSorted()
	{
		bool flag;
		if (isEmpty())
			flag = true;
		else { 
			ListNode<Object>* tmp=first();
			flag = isSortedrec(tmp);
		}
		return flag;
	}

	List<Object> operator+(const List& lst)
	{
		List<Object> tmp;
		ListNode<Object>* p=first();  
		ListNode<Object>* q=tmp.zeroth();

		for (; p!=NULL; p=p->next, q=q->next)
			tmp.insert(p->element, q);

		for (p=lst.first(); p!=NULL; p=p->next, q=q->next)
			tmp.insert(p->element, q);

		return tmp;
	}

    private:
        ListNode<Object> *head;

	void printrec(ListNode<Object>*  p)
	{
		if (p != NULL)
		{
			cout << p->element << endl;
			printrec(p->next);
		}
	}

	void printRevrec(ListNode<Object>*  p)
	{
		if (p != NULL)
		{
			printRevrec(p->next);
			cout << p->element << endl;
		}
	}

	bool isSortedrec(ListNode<Object>* p)
	{
		bool flag=true;
		if (p->next != NULL)
			flag = ((p->element < p->next->element) && (isSortedrec(p->next)));
		return flag;
	}


};


template <class Object>
class StackL
{
	public:

	void push(Object data)
	{
		
		stackList.insert(data, stackList.zeroth());
	}

	Object getTop() throw(string)
	{
		if (isEmpty())
			throw string("Exception:Stack is empty");
		return ((stackList.first())->element);
	}
	
	void pop() throw(string)
	{
		if (isEmpty())
			throw string("Exception:Stack is empty");
		stackList.remove((stackList.first())->element);
	}

	bool isEmpty()
	{
		return stackList.isEmpty();
	}

	private:
		List<Object> stackList;
};
	
