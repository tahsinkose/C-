#include <iostream>
#include "Stack.h"
#include <cstdlib>

using namespace std;

int main()
{

	Stack<char> myStack(100);

	char c;

	cout<<"Start entering text: ";

	cin >> c;

	try {
		while (c != '.'){ 
			if (c=='{') myStack.push(c);
			else if (c=='}') myStack.pop();
			cin >> c;
		}
	if (myStack.isEmpty())
		cout<<"Balanced brackets"<<endl;
	else
		cout<<"Exception:Unbalanced brackets"<<endl;	
	}
	catch(string s){cout<<"Exception:Unbalanced brackets"<<endl; }


	return 0;
}
