#include <iostream>
#include <string>
using namespace std;

template <class Object> 
class Stack {
private:
      int top;
      int capacity;
      Object* storage;

public:
      Stack(int cp) {
            if (cp <= 0)
                  throw string("Exception:Stack's capacity must be positive");
            storage = new Object[cp];
            capacity = cp;
            top = -1;
      }
 
      void push(Object value) {
            if (top == capacity-1)
                  throw string("Exception:Stack's is overflown");
            top++;
            storage[top] = value;
      }
 
      Object getTop() {
            if (top == -1)
                  throw string("Exception:Stack is empty");
            return storage[top];
      }
 
      void pop() {
            if (top == -1)
                  throw string("Exception:Stack is empty");
            top--;
      }
 
      bool isEmpty() {
            return (top == -1);
      }
 
      ~Stack() {
            delete[] storage;
      }

     void showContent() { //print the content from bottom to top
 	    int t=0;
	    if (!isEmpty()){
               cout<<"Stack: ";
	       for (int i=0; i<=top; i++)
		  cout<<storage[i]<<" ";
	       cout<<endl;		
	 }
	
    }
};
