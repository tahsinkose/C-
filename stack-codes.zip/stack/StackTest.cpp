#include <iostream>
//#include "StackDyn.h"
#include "StackL.h"

using namespace std;

int main()
{

	StackL<int> theStack;

	try {
	for (int i=0; i<10;i++)
		theStack.push(i);}
	catch(string s) {cout << s << endl;}


	try{
	for (int i=0; i<20;i++) {
			cout << theStack.getTop() << endl;
			theStack.pop(); } }
	catch(string s) {cout << s << endl;} 

	return 0;

}
	

